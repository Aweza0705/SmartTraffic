import seaborn as sns
import matplotlib.pyplot as plt

def generate_heatmap(result):
    coords = result.boxes.xyxy.cpu().numpy()
    x_centers = (coords[:, 0] + coords[:, 2]) / 2
    y_centers = (coords[:, 1] + coords[:, 3]) / 2
    plt.figure(figsize=(10, 8))
    sns.kdeplot(x=x_centers, y=y_centers, cmap="Reds", shade=True, bw_adjust=0.5)
    plt.title("Vehicle Density Heatmap")
    plt.xlabel("X Position")
    plt.ylabel("Y Position")
    plt.savefig("heatmap.png")
    plt.close()
