import sqlite3

def init_db():
    conn = sqlite3.connect('traffic_data.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS traffic_logs (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 image_name TEXT,
                 vehicle_count TEXT,
                 density_percentage REAL
    )''')
    conn.commit()
    conn.close()

def log_to_db(image_name, counts, avg_density):
    conn = sqlite3.connect('traffic_data.db')
    c = conn.cursor()
    c.execute("INSERT INTO traffic_logs (image_name, vehicle_count, density_percentage) VALUES (?, ?, ?)",
              (image_name, str(counts), avg_density))
    conn.commit()
    conn.close()
