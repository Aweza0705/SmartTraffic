from ultralytics import YOLO
import cv2

model = YOLO('yolov8n.pt')  # Lightweight model

def detect_vehicles(image_path):
    results = model(image_path)
    classes = results[0].names
    count = {name: 0 for name in classes.values()}
    for cls in results[0].boxes.cls:
        name = classes[int(cls)]
        count[name] += 1
    return count, results[0].plot()  # Returns count and image with bounding boxes
