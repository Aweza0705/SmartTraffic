from tkinter import messagebox, filedialog, simpledialog, Label, Button, Tk
import numpy as np
from CannyEdgeDetector import *
import matplotlib.image as mpimg
import cv2
import matplotlib.pyplot as plt
from PIL import Image, ImageTk
from ultralytics import YOLO
import seaborn as sns
from fpdf import FPDF
import sqlite3
import datetime
import os
 # This will create the table if it doesn't exist


# Load YOLOv8 model once globally
yolo_model = YOLO("yolov8n.pt")# use 'yolov8s.pt' for more accuracy


# Main application window
main = Tk()
#main.title("Dynamic Vehicles Enumeration and Classification Framework using Canny Edge Algorithm")
main.geometry("1300x1200")
#title = Label(main, text='My App Title', bg='yellow4', fg='white', font=('times', 16, 'bold'), anchor='center', justify='center')
#title.place(relx=0.5, y=5, anchor='n')  # relx=0.5 centers horizontally



# Frame for displaying output images (optional GUI output)
output_frame = Label(main, bg='white', width=510, height=410)
output_frame.place(x=600, y=150)

output_image_label = Label(output_frame)
output_image_label.pack()


# Load and set background image
# Load and set background image FIRST
img = Image.open("abc.png")
bg = ImageTk.PhotoImage(img.resize((1300, 1200), Image.Resampling.LANCZOS))
label = Label(main, image=bg)
label.place(x=0, y=0, relwidth=1, relheight=1)

# Then place the title so it's on top of the image
font = ('times', 16, 'bold')
title = Label(main,
              text='Dynamic Vehicles',
              bg='yellow4', fg='white', font=font, anchor='center', justify='center')
title.place(relx=0.5, y=1, anchor='n')


global filename
global refrence_pixels
global sample_pixels

def rgb2gray(rgb):
    r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
    gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
    return gray

def uploadTrafficImage():
    global filename
    filename = filedialog.askopenfilename(initialdir="images")
    pathlabel.config(text=filename)

def visualize(imgs, format=None, gray=False):
    j = 0
    plt.figure(figsize=(20, 40))
    for i, img in enumerate(imgs):
        if img.shape[0] == 3:
            img = img.transpose(1,2,0)
        plt_idx = i + 1
        plt.subplot(2, 2, plt_idx)
        if j == 0:
            plt.title('Sample Image')
            plt.imshow(img, format)
            j = j + 1
        elif j > 0:
            plt.title('Reference Image')
            plt.imshow(img, format)
    plt.show()

def applyCanny():
    imgs = []
    img = mpimg.imread(filename)
    img = rgb2gray(img)
    imgs.append(img)
    edge = CannyEdgeDetector(imgs, sigma=1.4, kernel_size=5, lowthreshold=0.09, highthreshold=0.20, weak_pixel=100)
    imgs = edge.detect()
    for i, img in enumerate(imgs):
        if img.shape[0] == 3:
            img = img.transpose(1,2,0)
    cv2.imwrite("gray/test.png", img)
    temp = []
    img1 = mpimg.imread('gray/test.png')
    img2 = mpimg.imread('gray/refrence.png')
    temp.append(img1)
    temp.append(img2)
    visualize(temp)

def pixelcount():
    global refrence_pixels
    global sample_pixels
    img = cv2.imread('gray/test.png', cv2.IMREAD_GRAYSCALE)
    sample_pixels = np.sum(img == 255)
    
    img = cv2.imread('gray/refrence.png', cv2.IMREAD_GRAYSCALE)
    refrence_pixels = np.sum(img == 255)
    messagebox.showinfo("Pixel Counts", "Total Reference White Pixels Count: " +str(refrence_pixels)+
                        "\nTotal Sample White Pixels Count: " +  str(sample_pixels))


def timeAllocation():
    global filename
    if not filename:
        messagebox.showerror("Error", "Upload an image first!")
        return

    # Run YOLO detection
    counts, _ = detect_vehicles_yolo(filename)

    # Count total number of detected vehicles
    total_vehicles = sum(counts.values())

    # Decide traffic level based on vehicle count
    if total_vehicles >= 20:
        time_msg = "Traffic is very high, allocation green signal time: 60 secs"
    elif total_vehicles >= 15:
        time_msg = "Traffic is high, allocation green signal time: 50 secs"
    elif total_vehicles >= 10:
        time_msg = "Traffic is moderate, allocation green signal time: 40 secs"
    elif total_vehicles >= 5:
        time_msg = "Traffic is low, allocation green signal time: 30 secs"
    else:
        time_msg = "Traffic is very low, allocation green signal time: 20 secs"

    # Show result
    messagebox.showinfo("Green Signal Allocation Time", f"{time_msg}\n\nVehicle Count: {total_vehicles}\nDetails: {counts}")



def detect_vehicles_yolo(image_path, show_plot=False):
    results = yolo_model(image_path)
    names = results[0].names
    counts = {}

    vehicle_classes = [2, 3, 5, 7]
    for cls in results[0].boxes.cls:
        class_id = int(cls)
        if class_id in vehicle_classes:
            name = names[class_id]
            counts[name] = counts.get(name, 0) + 1

    results[0].save(filename='detected_output.jpg')
    
    if show_plot:
        img_detected = mpimg.imread('detected_output.jpg')
        plt.figure(figsize=(10, 8))
        plt.imshow(img_detected)
        plt.title("YOLO Detected Vehicles")
        plt.axis('off')
        plt.show()
    
    return counts, results[0]


def generate_heatmap(result, show_plot=False):
    coords = result.boxes.xyxy.cpu().numpy()
    x_centers = (coords[:, 0] + coords[:, 2]) / 2
    y_centers = (coords[:, 1] + coords[:, 3]) / 2

    plt.figure(figsize=(10, 8))
    sns.kdeplot(x=x_centers, y=y_centers, cmap="Reds", fill=True, bw_adjust=0.5)
    plt.title("Vehicle Density Heatmap")
    plt.xlabel("X Position")
    plt.ylabel("Y Position")
    plt.savefig("heatmap.png")

    if show_plot:
        plt.show()

    plt.close()



def generate_pdf_report(counts, avg_density):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, "Traffic Analysis Report", ln=True, align="C")
    pdf.cell(200, 10, f"Date: {datetime.datetime.now()}", ln=True)
    pdf.cell(200, 10, f"Vehicle Counts: {str(counts)}", ln=True)
    pdf.cell(200, 10, f"Estimated Traffic Density: {avg_density:.2f}%", ln=True)
    pdf.image("heatmap.png", x=10, y=40, w=180)
    pdf.output("Traffic_Report.pdf")
    messagebox.showinfo("Report", "PDF Report Generated Successfully!")

def init_db():
    conn = sqlite3.connect('traffic_data.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS traffic_logs (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 image_name TEXT,
                 vehicle_count TEXT,
                 density_percentage REAL,
                 created_at TEXT
    )''')
    conn.commit()
    conn.close()

init_db()

    


def log_to_db(image_name, counts, avg_density):
    conn = sqlite3.connect('traffic_data.db')
    c = conn.cursor()
    c.execute("INSERT INTO traffic_logs (image_name, vehicle_count, density_percentage, created_at) VALUES (?, ?, ?, ?)",
              (image_name, str(counts), avg_density, str(datetime.datetime.now())))
    conn.commit()
    conn.close()
    messagebox.showinfo("Database", "Logged traffic data to DB!")

def runFullAnalysis():
    global filename
    if not filename:
        messagebox.showerror("Error", "Upload an image first!")
        return
    
    counts, result = detect_vehicles_yolo(filename)
    generate_heatmap(result)
    avg_density = (sample_pixels / refrence_pixels) * 100 if refrence_pixels else 0
    generate_pdf_report(counts, avg_density)
    log_to_db(filename.split("/")[-1], counts, avg_density)

def runYOLOOnly():
    global filename
    if not filename:
        messagebox.showerror("Error", "Upload an image first!")
        return

    counts, _ = detect_vehicles_yolo(filename, show_plot=True)

    try:
        img = Image.open("detected_output.jpg")
        img = img.resize((500, 400), Image.Resampling.LANCZOS)
        img_tk = ImageTk.PhotoImage(img)
        output_image_label.config(image=img_tk)
        output_image_label.image = img_tk

        for widget in output_frame.winfo_children():
            if isinstance(widget, Button):
                widget.destroy()

        close_btn = Button(output_frame, text="Close Image", command=lambda: output_image_label.config(image=''))
        close_btn.pack(pady=10)
    except Exception as e:
        messagebox.showerror("Error", f"Could not load YOLO image: {e}")

    messagebox.showinfo("YOLO Detection", f"Vehicle Counts:\n{counts}")


def showHeatmap():
    global filename
    if not filename:
        messagebox.showerror("Error", "Upload an image first!")
        return

    if not os.path.exists("detected_output.jpg"):
        messagebox.showwarning("Missing Detection", "Please run YOLO Detection first!")
        return

    _, result = detect_vehicles_yolo(filename, show_plot=False)
    generate_heatmap(result, show_plot=False)

    if os.path.exists("heatmap.png"):
        messagebox.showinfo("Heatmap", "Heatmap image has been saved successfully!")
    else:
        messagebox.showerror("Error", "Failed to save heatmap image.")


def showReportNotice():
    if not os.path.exists("Traffic_Report.pdf"):
        messagebox.showwarning("Report Missing", "Please generate report first.")
    else:
        messagebox.showinfo("Report", "Traffic_Report.pdf has been generated successfully.")



def exitApp():
    main.destroy()

#full_analysis = Button(main, text="Run YOLO + Heatmap + Report", command=runFullAnalysis, font=font1)
#full_analysis.place(x=50, y=400)


# Setting up the interface with the background image
font = ('times', 16, 'bold')
title = Label(main, text='Dynamic Vehicles Enumeration and Classification Framework using Canny-Edge and YOLO Algorithm', bg='#D8BFD8',     # Soft Lavender
              fg='#4B0082', anchor='w', justify='center')
title.config(font=font)           
title.config(height=2, width=80)       
title.place(x=50, y=3)

font1 = ('times', 14, 'bold')
upload = Button(main, text="Upload Traffic Image", command=uploadTrafficImage, font=font1)
upload.place(x=50, y=100)

pathlabel = Label(main, bg='#D8BFD8', fg='#4B0082', font=font1)
pathlabel.place(x=50, y=150)

process = Button(main, text="Image Preprocessing Using Canny Edge Detection", command=applyCanny, font=font1)
process.place(x=50, y=200)

count = Button(main, text="White Pixel Count", command=pixelcount, font=font1)
count.place(x=50, y=250)

yolo_button = Button(main, text="YOLO Detection", command=runYOLOOnly, font=font1)
yolo_button.place(x=50, y=300)

time_alloc = Button(main, text="Calculate Green Signal Time Allocation", command=timeAllocation, font=font1)
time_alloc.place(x=50, y=350)


heatmap_button = Button(main, text="Show Heatmap", command=showHeatmap, font=font1)
heatmap_button.place(x=50, y=400)

#report_button = Button(main, text="Report Status", command=showReportNotice, font=font1)
#report_button.place(x=50, y=450)


full_analysis = Button(main, text="Generate Report", command=runFullAnalysis, font=font1)
full_analysis.place(x=50, y=450)


exit_button = Button(main, text="Exit", command=exitApp, font=font1)
exit_button.place(x=50, y=500)

# Run the application
main.mainloop()