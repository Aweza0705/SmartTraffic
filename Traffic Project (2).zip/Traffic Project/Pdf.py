from fpdf import FPDF

def generate_pdf_report(counts, avg_density):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, "Traffic Analysis Report", ln=True, align="C")
    pdf.cell(200, 10, f"Vehicle Counts: {str(counts)}", ln=True)
    pdf.cell(200, 10, f"Estimated Traffic Density: {avg_density}%", ln=True)
    pdf.image("heatmap.png", x=10, y=40, w=180)
    pdf.output("Traffic_Report.pdf")
